Console.WriteLine("Welcome to RoslynScript!");
Console.WriteLine();

Console.WriteLine("3 ways to run:");
foreach (var line in GetMethods())
{
    Console.WriteLine(line);
}
public IEnumerable<string> GetMethods()
{
    yield return "1) Drop your 'test.cs' to 'RoslynScript.exe'";
    yield return "2) Right click 'test.cs' and click 'Roslyn Script'";
    yield return "3) Run 'RosylnScript test.cs'";
}

Console.WriteLine();
Console.WriteLine("Press enter to exit...");
Console.ReadLine();