Console.WriteLine("Welcome to RoslynScript!");

foreach (var line in Test())
{
    Console.WriteLine(line);
}

public IEnumerable<string> Test()
{
    yield return "1) Drop your 'test.cs' to 'RoslynScript.exe'";
    yield return "2) Right click 'test.cs' and click 'Roslyn Script'";
    yield return "3) Run 'RosylnScript test.cs'";
}

Console.WriteLine();
Console.WriteLine("Press enter to exit...");
Console.ReadLine();